<header>
<div></div>
<div class="titrePage">
    <h1>
        <?php echo $titrePage ?>
    </h1>
</div>
<div></div>
</header>
