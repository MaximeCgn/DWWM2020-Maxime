
<footer>
            <div></div>
            <div></div>
            <div></div>
        </footer>
    </div>
    <script src="script.js"></script>
</body>
</html>